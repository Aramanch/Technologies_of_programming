package org.example;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;
public class Main {
    public static void main(String[]args){
        Scanner in=new Scanner(System.in);
        System.out.println("Введите x для первого вектора:");
        double x=in.nextDouble();
        System.out.println("Введите y для первого вектора:");
        double y=in.nextDouble();
        System.out.println("Введите z для первого вектора:");
        double z=in.nextDouble();
        double[] v1 = {x, y, z};
        System.out.println("Введите x для второго вектора:");
        x=in.nextDouble();
        System.out.println("Введите y для второго вектора:");
        y=in.nextDouble();
        System.out.println("Введите z для второго вектора:");
        z=in.nextDouble();
        double[] v2 = {x, y, z};

        int choice = -1;
        while (choice != 7) {
            System.out.print(
                    """
                    \n=================================
                    1- Скалярное произведение
                    2- Векторное произведение
                    3- Сумма векторов
                    4- Разность векторов
                    5- Длина векторов
                    6- Угол между векторами
                    7- Выход\n
                    """);
            choice = in.nextInt();

            double[] v3 = {0, 0, 0};
            switch (choice) {
                case 1:
                {
                    System.out.println("Результат: "+vecMult(v1,v2));
                    break;
                }
                case 2:
                {
                    v3[0] = v1[1]*v2[2]-v1[2]*v2[1];
                    v3[1] = -(v1[0]*v2[2]-v1[2]*v2[0]);
                    v3[2] = v1[0]*v2[1]-v1[1]*v2[0];
                    System.out.println("Результат: "+Arrays.toString(v3));
                    break;
                }
                case 3:
                {
                    v3[0] = v1[0]+v2[0];
                    v3[1] = v1[1]+v2[1];
                    v3[2] = v1[2]+v2[2];
                    System.out.println("Результат: "+Arrays.toString(v3));
                    break;
                }
                case 4:
                {
                    v3[0] = v1[0]-v2[0];
                    v3[1] = v1[1]-v2[1];
                    v3[2] = v1[2]-v2[2];
                    System.out.println("Результат: "+Arrays.toString(v3));
                    break;
                }
                case 5:
                {
                    System.out.println("Длина 1-го вектора: "+vecLen(v1[0], v1[1], v1[2]));
                    System.out.println("Длина 2-го вектора: "+vecLen(v2[0], v2[1], v2[2]));
                    break;
                }
                case 6:
                {
                    double scalarMult = vecMult(v1, v2);
                    double v1Len = vecLen(v1[0], v1[1], v1[2]);
                    double v2Len = vecLen(v2[0], v2[1], v2[2]);
                    double result = scalarMult/(v1Len*v2Len);
                    System.out.println("Результат: "+(Math.acos(result)*180/Math.PI));
                    break;
                }
                case 7:
                {
                    System.out.println("Выход...");
                    break;
                }
                default:
                {
                    System.out.println("Incorrect command");

                }
            }
        }
    }
    static double vecLen(double a, double b, double c){
        return (Math.sqrt(Math.pow(a, 2)+Math.pow(b, 2)+Math.pow(c, 2)));
    }

    static double vecMult(double[] a, double[] b){
        return a[0]*b[0]+a[1]*b[1]+a[2]*b[2];
    }
}