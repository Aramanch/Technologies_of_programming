package org.example;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import static java.lang.String.format;

public class Main {
    public final static String emptyFileName="Input.txt";
    public final static String textFileName="/home/aram/IdeaProjects/Files/src/main/resources/file2.txt";
    public final static String textResults="Results.txt";
    public final static String textInput="/home/aram/IdeaProjects/Files/src/main/resources/input.txt";

    public static boolean isNumeric(final String str) {
        if(str == null || str.length() == 0) {
            return false;
        }
        return str.chars().allMatch(Character::isDigit);
    }

    public static ArrayList<Double> searchNumber(String result) {

        ArrayList<String> words = new ArrayList<String>(Arrays.asList(result.split(" ")));
        ArrayList<Integer> bufferWordsInt = new ArrayList<>();
        ArrayList<Double> bufferWordsFloat = new ArrayList<>();
        ArrayList<String> buffer = new ArrayList<>();
        for(int i = 0; i < words.size(); i++) {
            if(isNumeric(words.get(i)) == true) {
                bufferWordsInt.add(Integer.parseInt(words.get(i)));
            }
            else {
                buffer.add(words.get(i));
            }
        }
        for(int i = 0; i < buffer.size(); i++) {
            try {
                bufferWordsFloat.add(Double.parseDouble(buffer.get(i)));
            }
            catch (Exception e) {
            }
        }

        System.out.println(format("Количество целых чисел: %s", bufferWordsInt.size()));
        System.out.println(format("Количество чисел с плавающей точкой: %s", bufferWordsFloat.size()));

        for (int i = 0; i < bufferWordsInt.size(); i++) {
            System.out.println(format("Целые числа в 16-чном формате: %s", Integer.toHexString(bufferWordsInt.get(i))));
        }

        for (int i = 0; i < bufferWordsFloat.size(); i++) {
            System.out.printf("Числа с плавающей точкой: %.2f %n", bufferWordsFloat.get(i));
        }
        return bufferWordsFloat;
    }


    public static void main(String[] args) {


/************* File creation and Deletion **************/
        System.out.println(format("Creating an empty file [%s]....", emptyFileName));
        File file = new File(emptyFileName);
        try {
            if (file.createNewFile()) {
                System.out.println("File creation successful!");

            } else {
                System.out.println("File creation failed!");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        System.out.println(format("Deleting file [%s]....", emptyFileName));
        System.out.println("Do you want to delete the file (Y or y for Yes)?");
        Scanner in=new Scanner(System.in);
        char choice=in.nextLine().charAt(0);
        if(choice=='Y' || choice=='y')
        {
            try {
                if (file.delete()) {
                    System.out.println("File deletion successful!");
                } else {
                    System.out.println("File deletion failed!");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
/******************* Writing to a text file ********************/
//        System.out.println(String.format("Writing to file [%s]", textFileName));
        try {
            FileWriter fstream1 = new FileWriter(textResults);// конструктор с одним параметром - для перезаписи
            BufferedWriter out1 = new BufferedWriter(fstream1); //  создаём буферезированный поток
            out1.write(""); // очищаем, перезаписав поверх пустую строку
            out1.close(); // закрываем
        } catch (Exception e)
        {System.err.println("Error in file cleaning: " + e.getMessage());}

/******************* Reading from a text file *************************/
//// using FileReader
//        System.out.println(String.format("Reading file [%s] using FileReader", textFileName));
//                StringBuilder sb= new StringBuilder();
//        try {
//            FileReader myReader = new FileReader(textFileName);
//            int character=myReader.read();
//            while(character!=-1)
//            {
////System.out.print((char) character);
//                sb.append((char) character);
//                character=myReader.read();
//            }
//            myReader.close();
//        } catch (Exception e) {
//            System.out.println("Text reading failed.");
//            e.printStackTrace();
//        }
//        System.out.println(sb.toString());
// using Scanner
        System.out.println(format("Reading file[%s] using Scanner", textFileName));
        int counter = 0;
        int lowerCase = 0, upperCase = 0;
        int spaceCount = 0;
        int countPuncMarks = 0;
        int qInt = 0;
        int qReal = 0;
        int final_qInt = 0;
        int final_qReal = 0;

        try {
            File myFile = new File(textFileName);
            Scanner myReader = new Scanner(myFile);
            while (myReader.hasNextLine()) {

                String line = myReader.nextLine();
//                1
                String[] words = line.split("[\\s]+");
                System.out.println(Arrays.toString(words));
                counter = counter + words.length;
//                2
                for (int k = 0; k < line.length(); k++) {
                    if (Character.isUpperCase(line.charAt(k))) upperCase++;
                    if (Character.isLowerCase(line.charAt(k))) lowerCase++;
                }
//                3

                for (char c : line.toCharArray()) {
                    if (c == ' ') {
                        spaceCount++;
                    }
                }
//                4
//                System.out.println("5. Подсчитать количество целых чисел и чисел с плавающей запятой. В случае обнаружения целых чисел\n" +
//                        "программа должна вывести их в шестнадцатеричном формате. В случае обнаружения чисел с плавающей точкой\n" +
//                        "программа должна вывести их с двумя десятичными знаками (используйте метод String.format()).");
                searchNumber(line);



//                5

                for (int i = 0; i < line.length(); i++) {
                    if (line.charAt(i) == ',' | line.charAt(i) == '.' | line.charAt(i) == '!' | line.charAt(i) == '?'){
                        countPuncMarks++;
                    }
                }
                line = line.replaceAll("[\\pP]", "");
                System.out.println(line);
//               6
//                File cleaned then writing

                try {
                    FileWriter myWriter = new FileWriter(textResults, true);
                    myWriter.write(line+"\n");
                    myWriter.close();
//                    System.out.println("Text saved successfully.");
                } catch (Exception e) {
                    System.out.println("Text saving failed.");
                    e.printStackTrace();
                }
            }
            myReader.close();
        } catch (Exception e) {
            System.out.println("Text reading failed.");
            e.printStackTrace();
        }

        System.out.println("1. Quantity of words: "+counter);
        System.out.printf("2. In summary %d upper symbols and %d lower symbols. Total %d\n", upperCase, lowerCase, upperCase+lowerCase);
        System.out.println("3. Quantity of spaces: "+spaceCount);
        System.out.println("5. Quantity of puctuation marks: "+countPuncMarks);
//        8
        System.out.println("Please, input a word: ");
        Scanner myObj = new Scanner(System.in);
        String word = myObj.nextLine();

        char first = word.toCharArray()[0];
        char last = word.toCharArray()[word.length() - 1];
        try {
            File myFile = new File(textInput);
            Scanner myReader = new Scanner(myFile);
            while (myReader.hasNextLine()) {
                String line = myReader.nextLine();
                int ind0 = 0;
                int ind1 = 0;
                while(ind0 != -1) {
//                    System.out.println(line);
                    ind0 = line.indexOf(word, ind1);
                    ind1 = ind0 + (word.length() - 1);
                    if (ind0 != -1) {
                        System.out.println(ind0 + " " + (ind1));
                    }
                }

            }
            myReader.close();
        } catch (Exception e) {
            System.out.println("Text reading failed.");
            e.printStackTrace();
        }
    }
}